# BeSman

**BeSman** , is a command line utility inspired from sdkman !!
BESMan gives you a *bes* command on your shell , you can use it to automate the setup of various development environments required for BES projects  


# BESMAN! CLI
### The KochiOrgBook Manager Command Line Interface<!--Text-->

<!--Text-->

<!--
<!--[![Build Status](https://travis-ci.org/besman/besman-cli.svg?branch=master)](https://travis-ci.org/besman/besman-cli)
[![Latest Version](https://api.bintray.com/packages/besman/generic/besman-cli/images/download.svg) ](https://bintray.com/besman/generic/besman-cli/_latestVersion)
[![Backers on Open Collective](https://opencollective.com/besman/backers/badge.svg)](#backers)
[![Sponsors on Open Collective](https://opencollective.com/besman/sponsors/badge.svg)](#sponsors)
[![Slack](https://slack.besman.io/badge.svg)](https://slack.besman.io)
-->

BESMAN is a tool for managing parallel Versions of multiple KochiOrgBook projects on any Unix based system. It provides a convenient command line interface for installing, removing and listing Environments.

See documentation on the [BESMAN! website](https://besman.github.io).

## System pre-requisite

  - OS          : Ubuntu 18.04LTS
  - Memory[RAM]): 4GB (min)
  - Storage     : 30GB (min)


## Installation

Open your favourite terminal and enter the following:

    $ curl -L https://raw.githubusercontent.com/hyperledgerkochi/BeSman/dist/dist/get.besman.io | bash

If the environment needs tweaking for BESMAN to be installed, the installer will prompt you accordingly and ask you to restart.


### Local Installation

To install BESMAN locally running against your local server, run the following commands:


	$ source ~/.besman/bin/besman-init.sh


### Local environment commands

Run the following commands on the terminal to manage respective environments.

### Install commands:

        $ bes install -env [environment_name] --version [version_tag]

        Example   :
           $ bes install -env BeSman --version 0.0.2

Please run the following command to get the list of other environments and its versions.

	   	`$ bes list`

____________________

### Uninstall commands:

        $ bes uninstall -env [environment_name] --version [version_tag]

        Example   :
           $ bes uninstall -env BeSman --version 0.0.2

____________________

### Version commands:

    $ bes --version
    $ bes --version -env [environment_name]

    Example   :
       $ bes --version -env BeSman

____________________

### Other useful commands:        

        $ bes list
        $ bes status        
        $ bes help     

## Contributors

This project exists thanks to all the people who contribute.
<a href="https://github.com/besman/BeSman/graphs/contributors"><img src="https://i.stack.imgur.com/kk4j4.jpg" /></a>
